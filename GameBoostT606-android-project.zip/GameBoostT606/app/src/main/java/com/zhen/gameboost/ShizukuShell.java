package com.zhen.gameboost;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;

import rikka.shizuku.Shizuku;

/**
 * Runs `sh -c <cmd>` as the shell user (uid 2000) through Shizuku.
 *
 * Shizuku 13.x made newProcess() private (it nudges devs toward UserService), but it still works
 * and is what most Shizuku shell tools use. It lives in Java because Kotlin's compiler blocks the
 * reflective call pattern more awkwardly. Stdout and stderr are drained on separate threads so a
 * chatty command can never deadlock on a full pipe.
 */
public final class ShizukuShell {

    public static final class Result {
        public final int code;
        public final String out;
        public final String err;
        Result(int code, String out, String err) { this.code = code; this.out = out; this.err = err; }
    }

    private static volatile Method newProcess;
    private static final int MAX_OUTPUT = 256 * 1024; // keep the WebView bridge snappy

    private ShizukuShell() {}

    private static Method method() throws NoSuchMethodException {
        Method m = newProcess;
        if (m == null) {
            m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            newProcess = m;
        }
        return m;
    }

    public static Result run(String cmd) {
        Process p = null;
        try {
            if (!Shizuku.pingBinder()) return new Result(-1, "", "Shizuku is not running");
            p = (Process) method().invoke(null, new String[]{"sh", "-c", cmd}, null, null);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ByteArrayOutputStream err = new ByteArrayOutputStream();
            Thread to = pump(p.getInputStream(), out);
            Thread te = pump(p.getErrorStream(), err);
            try { p.getOutputStream().close(); } catch (Exception ignored) {}
            int code = p.waitFor();
            to.join(2000);
            te.join(2000);
            return new Result(code, out.toString(StandardCharsets.UTF_8.name()), err.toString(StandardCharsets.UTF_8.name()));
        } catch (InvocationTargetException e) {
            Throwable c = e.getCause() != null ? e.getCause() : e;
            return new Result(-1, "", "Shizuku: " + c);
        } catch (Throwable t) {
            return new Result(-1, "", String.valueOf(t));
        } finally {
            if (p != null) try { p.destroy(); } catch (Throwable ignored) {}
        }
    }

    private static Thread pump(InputStream in, ByteArrayOutputStream sink) {
        Thread t = new Thread(() -> {
            byte[] buf = new byte[8192];
            int n;
            try {
                while ((n = in.read(buf)) != -1) {
                    if (sink.size() < MAX_OUTPUT) sink.write(buf, 0, Math.min(n, MAX_OUTPUT - sink.size()));
                }
            } catch (Exception ignored) {
            } finally {
                try { in.close(); } catch (Exception ignored) {}
            }
        }, "shizuku-pump");
        t.setDaemon(true);
        t.start();
        return t;
    }
}
