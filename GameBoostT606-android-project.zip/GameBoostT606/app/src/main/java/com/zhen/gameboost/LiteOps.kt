package com.zhen.gameboost

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * BACKUP MODE: what GameBoost can do with its *own* permissions when Shizuku is off.
 *  - WRITE_SECURE_SETTINGS (one-time `pm grant`, survives reboot): Settings.Global / Secure / System writes
 *  - KILL_BACKGROUND_PROCESSES (normal permission, auto-granted): gentle background kill
 *  - plain intents: launching the game
 * Output text mirrors the shell output formats so the HTML parses both the same way.
 */
class LiteOps(private val ctx: Context) {

    data class Result(val code: Int, val out: String, val err: String = "")

    private val pm: PackageManager = ctx.packageManager
    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val main = Handler(Looper.getMainLooper())

    fun hasSecure(): Boolean =
        ctx.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    /** Runs op; long ones (launch + delayed sweep) call back later through [done]. */
    fun run(json: String, done: (Result) -> Unit) {
        val op = try { JSONObject(json) } catch (e: Exception) { return done(Result(-1, "", "bad op json")) }
        try {
            when (op.optString("op")) {
                "status" -> done(Result(0, status()))
                "getMany" -> done(Result(0, getMany(op.getJSONArray("keys"))))
                "put" -> done(put(op.getString("ns"), op.getString("key"), op.getString("value")))
                "delete" -> done(delete(op.getString("ns"), op.getString("key")))
                "mem" -> done(Result(0, mem()))
                "installed" -> done(Result(0, thirdParty().joinToString("\n")))
                "kill" -> done(Result(0, kill(excludes(op)) + "\n" + mem()))
                "launch" -> launch(op, done)
                else -> done(Result(-1, "", "unknown op"))
            }
        } catch (t: Throwable) {
            done(Result(-1, "", t.toString()))
        }
    }

    // ---------- settings ----------
    private fun put(ns: String, key: String, value: String): Result {
        val cr = ctx.contentResolver
        val ok = when (ns) {
            "global" -> Settings.Global.putString(cr, key, value)
            "secure" -> Settings.Secure.putString(cr, key, value)
            "system" -> Settings.System.putString(cr, key, value)
            else -> return Result(-1, "", "bad namespace")
        }
        return if (ok) Result(0, "ok") else Result(1, "", "write refused: $ns/$key")
    }

    private fun delete(ns: String, key: String): Result {
        // SettingsProvider's DELETE_<table> call removes the row (same as `settings delete`).
        val uri = when (ns) {
            "global" -> Settings.Global.CONTENT_URI
            "secure" -> Settings.Secure.CONTENT_URI
            "system" -> Settings.System.CONTENT_URI
            else -> return Result(-1, "", "bad namespace")
        }
        return try {
            ctx.contentResolver.call(uri, "DELETE_$ns", key, null)
            Result(0, "ok")
        } catch (t: Throwable) {
            Result(1, "", "delete refused: $ns/$key (${t.javaClass.simpleName})")
        }
    }

    private fun get(ns: String, key: String): String? {
        val cr = ctx.contentResolver
        return try {
            when (ns) {
                "global" -> Settings.Global.getString(cr, key)
                "secure" -> Settings.Secure.getString(cr, key)
                "system" -> Settings.System.getString(cr, key)
                else -> null
            }
        } catch (t: Throwable) { null }
    }

    private fun getMany(keys: JSONArray): String {
        val sb = StringBuilder()
        for (i in 0 until keys.length()) {
            val k = keys.getJSONArray(i)
            sb.append(k.getString(0)).append('/').append(k.getString(1)).append('=').append(get(k.getString(0), k.getString(1)) ?: "null").append('\n')
        }
        sb.append("prop/debug.hwui.renderer=").append(prop("debug.hwui.renderer"))
        return sb.toString()
    }

    // ---------- device ----------
    private fun prop(name: String): String = try {
        val c = Class.forName("android.os.SystemProperties")
        c.getMethod("get", String::class.java).invoke(null, name) as String
    } catch (t: Throwable) { "" }

    @Suppress("DEPRECATION")
    private fun status(): String {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val mode = wm.defaultDisplay.mode
        val angle = listOf("com.google.android.angle", "com.android.angle").any {
            try { pm.getPackageInfo(it, 0); true } catch (e: Exception) { false }
        }
        val soc = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else prop("ro.soc.model")
        val lcdDensity = prop("ro.sf.lcd_density").ifEmpty { ctx.resources.displayMetrics.densityDpi.toString() }
        val m = mem().replace("\n", ";")
        return listOf(
            "sdk=${Build.VERSION.SDK_INT}", "rel=${Build.VERSION.RELEASE}", "model=${Build.MODEL}",
            "device=${Build.DEVICE}", "soc=$soc", "board=${prop("ro.board.platform")}",
            "hwui=${prop("debug.hwui.renderer")}", "vk=${prop("ro.hardware.vulkan")}",
            "gfxdrv=${prop("ro.gfx.driver.0")}", "angle=${if (angle) 1 else 0}",
            "size=Physical size: ${mode.physicalWidth}x${mode.physicalHeight};",
            "density=Physical density: $lcdDensity;",
            "mem=$m;", "peak=${get("system", "peak_refresh_rate") ?: "null"}", "uid=${Process.myUid()}"
        ).joinToString("\n")
    }

    private fun mem(): String = try {
        File("/proc/meminfo").readLines()
            .filter { it.startsWith("MemTotal:") || it.startsWith("MemAvailable:") }
            .joinToString("\n") { it.replace(Regex("\\s+"), " ") }
    } catch (t: Throwable) {
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        "MemTotal: ${mi.totalMem / 1024} kB\nMemAvailable: ${mi.availMem / 1024} kB"
    }

    // ---------- RAM ----------
    private fun thirdParty(): List<String> =
        pm.getInstalledApplications(0)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
            .map { it.packageName }

    private fun excludes(op: JSONObject): Set<String> {
        val ex = mutableSetOf(ctx.packageName, "moe.shizuku.privileged.api")
        op.optJSONArray("exclude")?.let { a -> for (i in 0 until a.length()) ex.add(a.getString(i)) }
        // launcher + keyboard are always protected
        pm.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            ?.activityInfo?.packageName?.let { ex.add(it) }
        get("secure", "default_input_method")?.substringBefore('/')?.let { ex.add(it) }
        return ex
    }

    /** killBackgroundProcesses only drops processes Android already considers safe to kill. */
    private fun kill(exclude: Set<String>): String {
        var n = 0
        for (p in thirdParty()) {
            if (p in exclude) continue
            try { am.killBackgroundProcesses(p); n++ } catch (_: Throwable) {}
        }
        return "KILLED=$n"
    }

    private fun launch(op: JSONObject, done: (Result) -> Unit) {
        val pkg = op.getString("pkg")
        val intent = pm.getLaunchIntentForPackage(pkg)
            ?: return done(Result(1, "LAUNCH_FAILED", "no launcher activity for $pkg"))
        main.post {
            try {
                ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
            } catch (t: Throwable) {
                done(Result(1, "LAUNCH_FAILED", t.toString())); return@post
            }
            val delay = op.optInt("sweepAfter", 0)
            if (delay <= 0) { done(Result(0, "launched $pkg\n" + mem())); return@post }
            val ex = excludes(op) + pkg
            main.postDelayed({
                Thread { done(Result(0, "launched $pkg\n" + kill(ex) + "\n" + mem())) }.start()
            }, delay * 1000L)
        }
    }
}
