package com.zhen.gameboost

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

/**
 * Thin native shell around assets/index.html.
 * JS -> native : window.ShizukuBridge.{state, requestPermission, exec, getPackageName, copy, hasSecure, lite}
 * native -> JS : window.__gbResult(id, code, out, err), __gbPermission(granted), __gbState()
 */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private val pool = Executors.newFixedThreadPool(3)
    private var pageReady = false
    private val liteOps by lazy { LiteOps(applicationContext) }

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, result ->
        if (requestCode == REQ_SHIZUKU) {
            js("window.__gbPermission && window.__gbPermission(${result == PackageManager.PERMISSION_GRANTED})")
        }
    }
    private val binderReceived = Shizuku.OnBinderReceivedListener { js("window.__gbState && window.__gbState()") }
    private val binderDead = Shizuku.OnBinderDeadListener { js("window.__gbState && window.__gbState()") }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true       // GameBoost keeps its settings + snapshot in localStorage
            allowContentAccess = false
            setSupportZoom(false)
        }
        web.setBackgroundColor(0xFF14213D.toInt())
        web.webViewClient = object : WebViewClient() {
            // The bridge is powerful (shell access). Never let the WebView navigate anywhere else.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                !request.url.toString().startsWith("file:///android_asset/")

            override fun onPageFinished(view: WebView, url: String) { pageReady = true }
        }
        web.addJavascriptInterface(Bridge(), "ShizukuBridge")

        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionListener)

        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (pageReady) js("window.__gbState && window.__gbState()")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        js("(function(){var s=document.getElementById('scrim'); if(s && s.classList.contains('on')){window.closeSheet(); return 1;} return 0;})()") { handled ->
            if (handled != "1") super.onBackPressed()
        }
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        pool.shutdownNow()
        web.destroy()
        super.onDestroy()
    }

    private fun js(code: String, cb: ((String) -> Unit)? = null) = runOnUiThread {
        if (!isFinishing && !isDestroyed) web.evaluateJavascript(code) { cb?.invoke(it ?: "") }
    }

    inner class Bridge {
        @JavascriptInterface
        fun getPackageName(): String = this@MainActivity.packageName

        @JavascriptInterface
        fun state(): String = try {
            when {
                !Shizuku.pingBinder() -> "not_running"
                Shizuku.isPreV11() -> "old_version"
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> "ready"
                else -> "no_permission"
            }
        } catch (t: Throwable) { "error" }

        @JavascriptInterface
        fun requestPermission() = runOnUiThread {
            try {
                if (!Shizuku.pingBinder()) {
                    toast("Start Shizuku first")
                } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                    toast("You denied it before. Allow GameBoost inside the Shizuku app.")
                } else {
                    Shizuku.requestPermission(REQ_SHIZUKU)
                }
            } catch (t: Throwable) { toast("Shizuku error: ${t.message}") }
        }

        @JavascriptInterface
        fun exec(id: String, cmd: String) {
            pool.execute {
                val r: ShizukuShell.Result? = if (state() == "ready") ShizukuShell.run(cmd) else null
                if (r == null) {
                    js("window.__gbResult(${JSONObject.quote(id)}, -1, '', 'Shizuku not ready')")
                } else {
                    js("window.__gbResult(${JSONObject.quote(id)}, ${r.code}, ${JSONObject.quote(r.out)}, ${JSONObject.quote(r.err)})")
                }
            }
        }

        /** True once `pm grant <pkg> android.permission.WRITE_SECURE_SETTINGS` has been run (one time). */
        @JavascriptInterface
        fun hasSecure(): Boolean = liteOps.hasSecure()

        /** Backup mode: settings / gentle kill / launch with the app's own permissions. */
        @JavascriptInterface
        fun lite(id: String, json: String) {
            pool.execute {
                liteOps.run(json) { r ->
                    js("window.__gbResult(${JSONObject.quote(id)}, ${r.code}, ${JSONObject.quote(r.out)}, ${JSONObject.quote(r.err)})")
                }
            }
        }

        @JavascriptInterface
        fun copy(text: String) = runOnUiThread {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("GameBoost", text))
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object { private const val REQ_SHIZUKU = 7001 }
}
